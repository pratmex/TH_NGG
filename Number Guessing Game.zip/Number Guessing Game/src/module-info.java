/**
 * 
 */
/**
 * 
 */
module NumberGuessingGame {
	requires java.desktop;
}